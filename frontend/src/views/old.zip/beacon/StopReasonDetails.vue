<template>
	<v-container fluid>
		<v-row>
			<v-col cols="12">
				<stop-reason-list-card of="GROUP" :id="id" />
			</v-col>
		</v-row>
	</v-container>
</template>

<script>
import StopReasonListCard from './cards/StopReasonListCard'

export default {
	components: {
		StopReasonListCard,
	},
	computed: {
		id() {
			return Number(this.$route.params.id);
		}
	},
};
</script>
