<template>
	<v-container fluid>
		<v-row>
			<v-col cols="12">
				<v-card :loading="loading">
					<v-card-title>DETECTOR EDIT</v-card-title>
					<v-col cols="12">
						<v-text-field label="Unique" disabled :value="input.unique"></v-text-field>
						<v-text-field label="Name" v-model="input.name"></v-text-field>
						<v-select label="Beacon" v-model="input.beacon" :items="beacons" item-text="name" item-value="id" clearable></v-select>
						<v-text-field label="Connect Count" disabled :value="input.connectCount"></v-text-field>
					</v-col>
					<v-card-actions>
						<v-btn v-if="error" text color="error" :disabled="loading" v-text="error" @click="refresh()"></v-btn>
						<v-spacer></v-spacer>
						<v-btn text color="primary" :disabled="loading" @click="refresh()">REFRESH</v-btn>
						<v-btn text color="primary" @click="cancel()">CANCEL</v-btn>
						<v-btn text color="primary" :disabled="loading && !detector" @click="update()">SAVE</v-btn>
					</v-card-actions>
				</v-card>
			</v-col>
		</v-row>
	</v-container>
</template>

<script>
export default {
	data() {
		return {
			loading: false,
			error: null,
			detector: null,
			input: {
				unique: null,
				name: null,
				beacon: null,
				connectCount: null,
			},
			beacons: [],
		};
	},
	methods: {
		updateInputs(payload) {
			this.detector = payload;

			this.input.unique = this.detector.unique;
			this.input.name = this.detector.name;
			this.input.beacon = (this.detector.beacon || {}).id;
			this.input.connectCount = this.detector.connectCount;
		},
		refresh() {
			this.loading = true;

			Promise.all([
				this.$http
					.get("/beacon/detector/" + this.$route.params.id)
					.then((response) => {
						this.updateInputs(response.data.payload);
					})
					.catch((error) => {
						this.error = error;
					}),
				this.$http
					.get("beacon")
					.then((response) => {
						this.error = null;
						this.beacons = response.data.payload;
					})
					.catch((error) => {
						this.error = error;
					}),
			]).then((values) => {
				this.loading = false;
			});
		},
		update() {
			this.loading = true;

			this.$http
				.post("/beacon/detector/" + this.$route.params.id, {
					name: this.input.name,
					beacon: this.input.beacon,
				})
				.then((response) => {
					this.error = null;
					this.updateInputs(response.data.payload);
				})
				.catch((error) => {
					this.error = error;
				})
				.then((values) => {
					this.loading = false;
				});
		},
		cancel() {
			// TODO
		}
	},
	created() {
		this.refresh();
	},
};
</script>
