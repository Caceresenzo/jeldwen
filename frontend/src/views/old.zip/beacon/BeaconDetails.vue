<template>
	<v-container fluid>
		<v-row>
			<v-col cols="12">
				<loading-card :title="'PROPERTIES'" :endpoint="'/beacon/' + id">
					<template v-slot="{ payload }">
						syntheticPerformanceRate: {{ payload }}
					</template>
				</loading-card>
			</v-col>
			<v-col cols="12">
				<stop-reason-list-card of="BEACON" :id="id" />
			</v-col>
			<v-col cols="12">
				<stop-reason-group-list-card of="BEACON" :id="id" />
			</v-col>
		</v-row>
	</v-container>
</template>

<script>
import BeaconListCard from "./cards/BeaconListCard";
import StopReasonListCard from "./cards/StopReasonListCard";
import StopReasonGroupListCard from "./cards/StopReasonGroupListCard";

export default {
	name: "Beacons",
	components: {
		BeaconListCard,
		StopReasonListCard,
		StopReasonGroupListCard,
	},
	data() {
		return {
			loading: false,
			error: null,
			beacons: [],
		};
	},
	computed: {
		id() {
			return Number(this.$route.params.id);
		},
	},
	methods: {
		fetchBeacons() {
			this.loading = true;

			this.$http
				.get("beacon")
				.then((response) => {
					this.error = null;
					this.beacons = response.data.payload;
				})
				.catch((error) => {
					this.error = error;
				})
				.then(() => {
					this.loading = false;
				});
		},
	},
	created() {
		this.fetchBeacons();
	},
};
</script>
