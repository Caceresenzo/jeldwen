<template>
	<list-card :title="'DETECTORS'" endpoint="/beacon/detector" :linkFormatter="(item) => '/beacon/detector/' + item.id">
		<template v-slot="{ item }">
			<v-list-item-avatar>
				<v-icon>folder</v-icon>
			</v-list-item-avatar>
			<v-list-item-content v-if="item.name">
				<v-list-item-title v-text="item.name"></v-list-item-title>
				<v-list-item-subtitle v-text="item.unique"></v-list-item-subtitle>
			</v-list-item-content>
			<v-list-item-content v-else>
				<v-list-item-title v-text="item.unique"></v-list-item-title>
			</v-list-item-content>
			<v-list-item-icon v-if="!item.name">
				<v-chip color="error">Not configured</v-chip>
			</v-list-item-icon>
		</template>
	</list-card>
</template>