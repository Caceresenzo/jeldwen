<template>
	<list-card :title="'STOP REASON (' + of + ')'" :endpoint="endpoint" :linkFormatter="linkFormatter">
		<template v-slot="{ item }">
			<v-list-item-avatar>
				<v-icon :color="item.color">folder</v-icon>
			</v-list-item-avatar>
			<v-list-item-content>
				<v-list-item-title v-text="item.name"></v-list-item-title>
			</v-list-item-content>
			<v-list-item-avatar>
				<v-icon @click>delete</v-icon>
			</v-list-item-avatar>
		</template>
		<template v-slot:actions>
			<v-btn text color="primary" @click="addDialog = true">ADD</v-btn>
		</template>
	</list-card>
</template>

<script>
import Vuetify, { VBtn } from "vuetify/lib";

export default {
	name: "stop-reason-list-card",
	components: {
		VBtn,
	},
	props: {
		of: {
			type: String,
			validator: (val) => ["ALL", "BEACON", "GROUP"].includes(val.toUpperCase()),
			default: "ALL",
		},
		id: {
			type: Number,
			default: -1,
		},
	},
	data: () => ({
		payload: null,
		addDialog: false
	}),
	computed: {
		endpoint() {
			if (this.of == "BEACON") {
				return `/beacon/${this.id}/stop-reason`;
			} else if (this.of == "GROUP") {
				return `/beacon/stop-reason-group/${this.id}`;
			} else {
				return "/beacon/stop-reason";
			}
		},
	},
	methods: {
		linkFormatter(item) {
			return `/beacon/stop-reason/${this.id}`;
		},
	},
};
</script>