
<template>
	<list-card :title="'BEACONS'" endpoint="/beacon/" :linkFormatter="(item) => '/beacon/' + item.id">
		<template v-slot="{ item }">
			<v-list-item-avatar>
				<v-icon>folder</v-icon>
			</v-list-item-avatar>
			<v-list-item-content>
				<v-list-item-title v-text="item.name"></v-list-item-title>
			</v-list-item-content>
		</template>
	</list-card>
</template>

<script>
export default {
	name: "beacon-list-card"
};
</script>
