<template>
	<list-card :title="'STOP REASON GROUP (' + of + ')'" :endpoint="endpoint" :linkFormatter="linkFormatter">
		<template v-slot="{ item }">
			<v-list-item-avatar>
				<v-icon :color="item.color">folder</v-icon>
			</v-list-item-avatar>
			<v-list-item-content>
				<v-list-item-title v-text="item.name"></v-list-item-title>
				<v-list-item-subtitle v-text="item.children.length + ' item(s)'"></v-list-item-subtitle>
			</v-list-item-content>
			<v-list-item-actions>
				<v-icon>delete</v-icon>
			</v-list-item-actions>
		</template>
		<template v-slot:actions>
			<v-btn text color="primary" @click>ADD</v-btn>
		</template>
	</list-card>
</template>

<script>
import Vuetify, { VBtn } from "vuetify/lib";

export default {
	name: "stop-reason-group-list-card",
	components: {
		VBtn,
	},
	props: {
		of: {
			type: String,
			validator: (val) => ["ALL", "BEACON"].includes(val.toUpperCase()),
			default: "ALL",
		},
		id: {
			type: Number,
			default: -1,
		},
	},
	computed: {
		endpoint() {
			if (this.of == "BEACON") {
				return `/beacon/${this.id}/stop-reason-group`;
			} else {
				return "/beacon/stop-reason-group";
			}
		},
	},
	methods: {
		linkFormatter(item) {
			return `/beacon/stop-reason-group/${item.id}`;
		},
	},
};
</script>