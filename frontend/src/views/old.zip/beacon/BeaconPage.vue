<template>
	<v-container fluid>
		<v-row>
			<v-col cols="12">
				<beacon-list-card />
			</v-col>
			<v-col cols="12">
				<detector-list-card />
			</v-col>
		</v-row>
	</v-container>
</template>

<script>
import BeaconListCard from './cards/BeaconListCard'
import DetectorListCard from './cards/DetectorListCard'

export default {
	components: {
		BeaconListCard,
		DetectorListCard
	}
};
</script>
