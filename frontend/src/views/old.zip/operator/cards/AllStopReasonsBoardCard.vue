<template>
	<v-card>
		<v-col v-for="(object, index) of byCategory" :key="index" cols="12">
			<v-card-title class="py-0" v-text="object.category.name.toUpperCase()"></v-card-title>
			<v-row align="stretch">
				<v-col v-for="(stopReason, index) of object.children" :key="index">
					<v-card style="height: 100%;" :color="true ? stopReason.category.color : ''" @click>
						<v-card-text class="pb-0">
							<p v-text="stopReason.name.toUpperCase()"></p>
						</v-card-text>
					</v-card>
				</v-col>
			</v-row>
		</v-col>
	</v-card>
</template>

<script>
export default {
	name: "all-stop-reasons-board-card",
	data() {
		return {
			loading: false,
			error: null,
			stopReasons: [],
		};
	},
	computed: {
		byCategory: function () {
			let all = {};

			for (let stopReason of this.stopReasons) {
				let arr = all[stopReason.category.id] || { children: [], category: stopReason.category };
				arr.children.push(stopReason);
				all[stopReason.category.id] = arr;
			}

			return all;
		},
	},
	props: {
		id: {
			type: Number,
			default: -1,
		},
	},
	methods: {
		refresh() {
			this.loading = true;

			this.$http
				.get(`beacon/${this.id}/stop-reasons`)
				.then((response) => {
					this.error = null;
					this.stopReasons = response.data.payload;
				})
				.catch((error) => {
					this.error = error;
				})
				.then(() => {
					this.loading = false;
				});
		},
	},
	created() {
		this.refresh();
	},
};
</script>
