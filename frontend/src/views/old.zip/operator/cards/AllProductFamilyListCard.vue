<template>
	<v-card :loading="loading">
		<v-card-title>FAMILIES</v-card-title>
		<v-list>
			<v-list-item v-for="item in items" :key="item.id">
				<v-list-item-content>
					<v-list-item-title v-text="item.name"></v-list-item-title>
					<v-list-item-subtitle v-text="item.cycleTime + 's'"></v-list-item-subtitle>
				</v-list-item-content>
				<v-list-item-icon>
					<v-btn>START</v-btn>
				</v-list-item-icon>
			</v-list-item>
		</v-list>
	</v-card>
</template>

<script>
export default {
	name: "all-stop-reasons-board-card",
	props: {
		loading: {
			type: Boolean,
			default: false,
		},
		items: {
			type: Array,
			required: true,
		}
	},
};
</script>
