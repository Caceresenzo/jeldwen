<template>
	<v-container fluid>
		<v-row>
			<v-col cols="12">
				<v-card :loading="loading">
					<v-card-title>BEACONS</v-card-title>
					<v-list two-line subheader>
						<v-list-item v-for="beacon in beacons" :key="beacon.id" link :to="'/operator/' + beacon.id">
							<v-list-item-avatar>
								<v-icon>folder</v-icon>
							</v-list-item-avatar>
							<v-list-item-content>
								<v-list-item-title v-text="beacon.name"></v-list-item-title>
							</v-list-item-content>
						</v-list-item>
					</v-list>
					<v-card-actions>
						<v-btn v-if="error" text color="error" :disabled="loading" v-text="error" @click="refresh()"></v-btn>
						<v-spacer></v-spacer>
						<v-btn text color="primary" :disabled="loading" @click="refresh()">REFRESH</v-btn>
					</v-card-actions>
				</v-card>
			</v-col>
		</v-row>
	</v-container>
</template>

<script>
export default {
	data() {
		return {
			loading: false,
			error: null,
			beacons: [],
		};
	},
	methods: {
		refresh() {
			this.loading = true;

			this.$http
				.get("beacon")
				.then((response) => {
					this.error = null;
					this.beacons = response.data.payload;
				})
				.catch((error) => {
					this.error = error;
				})
				.then(() => {
					this.loading = false;
				});
		},
	},
	created() {
		this.refresh();
	},
};
</script>
