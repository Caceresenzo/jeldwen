<template>
	<v-container style="user-select: none;">
		<v-row>
			<v-col cols="2" class="pt-0">
				<v-col cols="12">
					<v-card color="success" @click>
						<v-card-title>FERMER POSTE</v-card-title>
					</v-card>
				</v-col>
				<v-col cols="12">
					<all-product-family-list-card :items="beacon.productFamilies" :loading="loading" :id="Number($route.params.id)" />
				</v-col>
				<v-col cols="12">
					<v-card>
						<v-card-title>CURRENT CYCLE</v-card-title>
						<v-card-text>
							<p class="subtitle-1 text-center">{{ seconds.value }}s / 12s</p>
							<v-progress-linear height="10" :value="Math.min(seconds.value / 12 * 100, 100)" :color="seconds.value / 12 > 1 ? 'error' : 'success'"></v-progress-linear>
						</v-card-text>
					</v-card>
				</v-col>
				<v-col cols="12">
					<v-card :disabled="currentStop == null" :color="currentStop ? currentStop.category.color : ''">
						<v-card-title>CURRENT STOP</v-card-title>
						<v-card-text v-if="currentStop">
							<p class="subtitle-1 text-center" v-text="currentStop.name"></p>
						</v-card-text>
					</v-card>
				</v-col>
			</v-col>
			<v-col cols="4" class="pt-0">
				<v-col cols="12">
					<v-card>
						<v-simple-table>
							<template v-slot:default>
								<thead>
									<tr>
										<th></th>
										<th class="text-left">Ouverture</th>
										<th class="text-left">Arrêt</th>
										<th class="text-left">Prod</th>
										<th class="text-left">Obj</th>
										<th class="text-left">TRS</th>
										<th></th>
									</tr>
								</thead>
								<tbody>
									<tr v-for="(item, index) of desserts" :key="index">
										<td>
											{{ item.hourStart }}
											<br />
											{{ item.hourStop }}
										</td>
										<td>{{ item.open }}</td>
										<td>{{ item.stop }}</td>
										<td>{{ item.production }}</td>
										<td>{{ item.objective }}</td>
										<td>{{ Math.round(item.production / item.objective * 100) }} %</td>
										<td>
											<v-btn :color="index % 2 ? 'error' : 'success'"></v-btn>
										</td>
									</tr>
								</tbody>
							</template>
						</v-simple-table>
					</v-card>
				</v-col>
				<v-col cols="12">
					<!--<all-stop-reasons-board-card :id="Number($route.params.id)" />-->
				</v-col>
			</v-col>
			<v-col cols="6" class="pt-0">
				<v-col cols="12">
					<all-stop-reasons-board-card :id="Number($route.params.id)" />
				</v-col>
			</v-col>
		</v-row>
	</v-container>
</template>

<script>
import AllStopReasonsBoardCard from "./cards/AllStopReasonsBoardCard";
import AllProductFamilyListCard from "./cards/AllProductFamilyListCard";

export default {
	components: {
		AllStopReasonsBoardCard,
		AllProductFamilyListCard,
	},
	data() {
		return {
			loading: false,
			error: null,
			currentStop: {
				id: 33,
				key: null,
				name: "Transferts",
				category: {
					id: 5,
					name: "Panne",
					color: "#7ECCD6",
				},
			},
			beacon: {
				productFamilies: [],
			},
			seconds: {
				value: 0,
				animation: 0,
				progress: 0,
			},
			desserts: [
				{
					hourStart: "08h",
					hourStop: "09h",
					open: "13:38",
					stop: "07:31",
					production: 8,
					objective: 9,
				},
				{
					hourStart: "09h",
					hourStop: "10h",
					open: "13:38",
					stop: "07:31",
					production: 8,
					objective: 9,
				},
				{
					hourStart: "10h",
					hourStop: "11h",
					open: "13:38",
					stop: "07:31",
					production: 8,
					objective: 9,
				},
				{
					hourStart: "10h",
					hourStop: "11h",
					open: "13:38",
					stop: "07:31",
					production: 8,
					objective: 9,
				},
				{
					hourStart: "10h",
					hourStop: "11h",
					open: "13:38",
					stop: "07:31",
					production: 8,
					objective: 9,
				},
				{
					hourStart: "10h",
					hourStop: "11h",
					open: "13:38",
					stop: "07:31",
					production: 8,
					objective: 9,
				},
				{
					hourStart: "10h",
					hourStop: "11h",
					open: "13:38",
					stop: "07:31",
					production: 8,
					objective: 9,
				},
				{
					hourStart: "10h",
					hourStop: "11h",
					open: "13:38",
					stop: "07:31",
					production: 8,
					objective: 9,
				},
			],
		};
	},
	methods: {
		refresh() {
			this.loading = true;

			this.$http
				.get("beacon/" + this.$route.params.id)
				.then((response) => {
					this.error = null;
					this.beacon = response.data.payload;
				})
				.catch((error) => {
					this.error = error;
				})
				.then(() => {
					this.loading = false;
				});
		},
	},
	created() {
		this.refresh();
		this.seconds.animation = setInterval(() => {
			this.seconds.value++;
		}, 1000);
	},
	destroyed() {
		clearInterval(this.seconds.animation);
	},
};
</script>
